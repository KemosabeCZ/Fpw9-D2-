from django.db import models
from django.contrib.auth.models import User

class Author(models.Model):
    author = models.OneToOneField(User, on_delete=models.CASCADE)
    rating = models.FloatField(default=0)


def update_rating(self):
    posted = Post.objects.filter(author=self)
    post_ratings = sum(i.rating for i in posted)
    comment_ratings = sum(i.rating for i in Comment.objects.filter(user=self.user))
    postcomment_ratings = 0
    for j in posted:
        for i in Comment.objects.filter(post=j):
            postcomment_ratings += i.rating
            self.rating = (3 * post_ratings) + comment_ratings + postcomment_ratings
            self.save()


class Category(models.Model):
    theme = models.CharField(max_length=64, unique=True)


class Post(models.Model):
    article = 'AT'
    news = 'NW'
    TYPES = [(article, 'Статья'), (news, 'Новость')]
    field = models.CharField(max_length=2, choices=TYPES, default=news)
    title = models.CharField(max_length=64, default="Default value")
    article = models.TextField()
    rating = models.FloatField(default=0)
    datetime = models.DateTimeField(auto_now_add=True)
    author_post = models.ForeignKey(Author, on_delete=models.CASCADE, verbose_name='Автор', blank=True, null=True)
    post_category = models.ManyToManyField(Category, through='PostCategory')


def preview(self):
    return str(self.text)[:123].replace('\n', ' ')


def like(self):
    self.rating += 1
    self.save()


def dislike(self):
    self.rating -= 1
    self.save()


class PostCategory(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)


class Comment(models.Model):
    commentary = models.TextField()
    comment_datetime = models.DateTimeField(auto_now_add=True)
    rating = models.FloatField(default=0)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)


def like(self):
    self.rating += 1
    self.save()


def dislike(self):
    self.rating -= 1
    self.save()


