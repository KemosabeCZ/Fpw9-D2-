from django.apps import AppConfig


class AppnewsConfig(AppConfig):
    name = 'appnews'
